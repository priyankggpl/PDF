import React from 'react'


function Sidebar() {
  return (
    <div className='sidebar'>
     <img id="side-img" src='/images/photo.jpg' />
     <a className='child' id='first'>Alex Smith</a> 
     <a className='child'>About Me</a> 
     <a className='child'>Resume</a> 
     <a className='child'>Portfolio</a> 
     <a className='child'>Blog</a> 
     <a className='child'>Contact</a> 
     <div className='icons'>
        <a href="#" target="_blank" class="social-icon">
        <i class="fab fa-twitter"></i>
        </a>
        <a href="#" target="_blank" class="social-icon">
        <i class="fab fa-facebook-f"></i>
        </a>
        <a href="#" target="_blank" class="social-icon">
        <i class="fab fa-instagram"></i>
        </a>
     </div>
    </div>
  )
}

export default Sidebar
